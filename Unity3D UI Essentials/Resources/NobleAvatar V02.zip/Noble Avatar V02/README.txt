The following is a set of avatar components I use in Age of Conquest (http://www.ageofconquest.com). I get a lot of request from people asking me to use the avatars in their own projects, so here you go :)

All files enclosed are licensed under CC-BY-3.0 (http://creativecommons.org/licenses/by/3.0/)
You are free to use the graphics/source both commercially and non-commercially as long as the following credits are included:

1. Credit Noble Master Games as follows (linking is optional):
   "Avatar graphics created by Noble Master Games" and link to http://www.noblemaster.com 
2. Credit the artist "Liea" as follows (optional):
   "Avatar graphics designed by Mei-Li Nieuwland" and link to http://liea.deviantart.com

I hope the graphics come in handy for someone. Oh and yes, there are over 15 Trillion avatar combinations if you layer them correctly :-D

Thanks,
Christoph Aschwanden
Twitter: http://twitter.com/noblemaster
Website: http://www.noblemaster.com

PS I: To play around with it, you can also visit the Noble Avatar website (http://www.nobleavatar.com/).
PS II: I included the source code too for the application that is on the Noble Avatar website if you are confused as to how to use the avatar components but I don't think you really need it. Although the source is in Java, you should be able to get the avatars to work in any other language/game developer's too. 